function [xout, tout] = hr_imputeLong(x,t,iout,dmax)
idone = [];
xout = x;
for i=1:length(iout)   % i = iout(
    k = 0;
    if isempty(find(iout(i)==idone))
        ii = (iout(i)-k):(iout(i)+k);
        while(sum(x(ii)) > dmax*length(ii))
            k = k + 1;
            ii = (iout(i)-k):(iout(i)+k);
        end
        ip = find(x(ii) > dmax);
        dp = sum(x(ii(ip)) - dmax)/length(ip);
        xout(ii(ip)) = x(ii(ip)) - dp;
    
        ip = find(x(ii) <= dmax);
        dp = sum(x(ii(ip)) - dmax)/length(ip);
        xout(ii(ip)) = x(ii(ip)) - dp;
        
        % figure, plot(xout), hold on, plot(iout, xout(iout),'*r')
        % plot(xout)
        % Add to the list of imputed outliers
        idone = [idone ii];
    end
end
% pdate tout
tout = cumsum(xout)/(1000*24*3600) + t(1);